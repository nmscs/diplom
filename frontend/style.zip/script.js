document.addEventListener('DOMContentLoaded', () => {
    // 1. Получаем необходимые элементы
    const track = document.getElementById('carouselTrack');
    const prevButton = document.getElementById('prevButton');
    const nextButton = document.getElementById('nextButton');

    // 2. Определяем настройки карусели
    const itemsPerView = 3; // Количество видимых элементов
    let currentIndex = 0; // Текущий индекс смещения (1 смещение = 1 элемент)

    // Вычисляем полную ширину одного элемента: ширина + маргины (280px + 10px + 10px = 300px)
    const itemFullWidth = 300;

    // Элементы
    const items = track.querySelectorAll('.carousel-item');
    const totalItems = items.length; // Общее количество "настоящих" элементов (6)

    // 3. Создаем "бесконечность": клонируем элементы

    // Клонируем последние 3 элемента и добавляем их в начало
    for (let i = totalItems - itemsPerView; i < totalItems; i++) {
        const clone = items[i].cloneNode(true);
        track.insertBefore(clone, items[0]);
    }

    // Клонируем первые 3 элемента и добавляем их в конец
    for (let i = 0; i < itemsPerView; i++) {
        const clone = items[i].cloneNode(true);
        track.appendChild(clone);
    }

    // 4. Изначально смещаем трек на ширину клонированных элементов, чтобы показать "настоящий" первый элемент
    const initialShift = itemsPerView * itemFullWidth;
    track.style.transform = `translateX(-${initialShift}px)`;

    // 5. Функция для смещения трека
    const moveTrack = () => {
        // Смещение: (3 клона в начале + текущий индекс) * полная ширина элемента
        const shiftAmount = (itemsPerView + currentIndex) * itemFullWidth;
        track.style.transform = `translateX(-${shiftAmount}px)`;
    };

    // 6. Обработчик для кнопки "Вперед" (Next)
    nextButton.addEventListener('click', () => {
        // Устанавливаем анимацию
        track.style.transition = 'transform 0.3s ease-in-out';
        currentIndex++;
        moveTrack();

        // Если дошли до конца (показали последний клон)
        if (currentIndex >= totalItems) {
            setTimeout(() => {
                track.style.transition = 'none'; // Мгновенное смещение
                currentIndex = 0; // Возвращаемся к "настоящему" началу
                moveTrack();
            }, 300); // 300 мс соответствует CSS transition
        }
    });

    // 7. Обработчик для кнопки "Назад" (Previous)
    prevButton.addEventListener('click', () => {
        track.style.transition = 'transform 0.3s ease-in-out';
        currentIndex--;
        moveTrack();

        // Если дошли до начала (показали первый клон)
        if (currentIndex < 0) {
            setTimeout(() => {
                track.style.transition = 'none'; // Мгновенное смещение
                currentIndex = totalItems - 1; // Возвращаемся к "настоящему" концу
                moveTrack();
            }, 300);
        }
    });

});document.addEventListener('DOMContentLoaded', () => {
    // 1. Получаем необходимые элементы
    const track = document.getElementById('carouselTrack');
    const prevButton = document.getElementById('prevButton');
    const nextButton = document.getElementById('nextButton');

    // 2. Определяем настройки карусели
    const itemsPerView = 3; // Количество видимых элементов (и наш шаг прокрутки)
    let currentIndex = 0; // Текущий индекс смещения (0 - первая страница, 3 - вторая страница)

    // Полная ширина одного элемента: 280px (ширина) + 10px + 10px (маргины) = 300px
    const itemFullWidth = 300;

    // Элементы
    const items = track.querySelectorAll('.carousel-item');
    const totalItems = items.length; // Общее количество "настоящих" элементов (6)

    // 3. Создаем "бесконечность": клонируем элементы
    // Клонируем последние 3 элемента и добавляем их в начало
    for (let i = totalItems - itemsPerView; i < totalItems; i++) {
        const clone = items[i].cloneNode(true);
        track.insertBefore(clone, items[0]);
    }

    // Клонируем первые 3 элемента и добавляем их в конец
    for (let i = 0; i < itemsPerView; i++) {
        const clone = items[i].cloneNode(true);
        track.appendChild(clone);
    }

    // 4. Изначально смещаем трек на ширину клонированных элементов, чтобы показать "настоящий" первый элемент
    const initialShift = itemsPerView * itemFullWidth;
    track.style.transform = `translateX(-${initialShift}px)`;

    // 5. Функция для смещения трека
    const moveTrack = () => {
        // Смещение: (3 клона в начале + текущий индекс) * полная ширина элемента
        // *ВНИМАНИЕ*: currentIndex теперь 0 или 3, что соответствует смещению на 0 или на 3 элемента.
        const shiftAmount = (itemsPerView + currentIndex) * itemFullWidth;
        track.style.transform = `translateX(-${shiftAmount}px)`;
    };

    // 6. Обработчик для кнопки "Вперед" (Next)
    nextButton.addEventListener('click', () => {
        // Устанавливаем анимацию
        track.style.transition = 'transform 0.3s ease-in-out';

        // *** ИЗМЕНЕНИЕ: Увеличиваем индекс на 3 (постраничная прокрутка) ***
        currentIndex += itemsPerView;
        moveTrack();

        // Если дошли до конца (показали последнюю страницу клонов)
        // Если у нас 6 элементов, то страницы 0 и 3. После 3 будет 6 (индекс totalItems).
        if (currentIndex >= totalItems) {
            setTimeout(() => {
                track.style.transition = 'none'; // Мгновенное смещение
                currentIndex = 0; // Возвращаемся к "настоящему" началу
                moveTrack();
            }, 300); // 300 мс соответствует CSS transition
        }
    });

    // 7. Обработчик для кнопки "Назад" (Previous)
    prevButton.addEventListener('click', () => {
        track.style.transition = 'transform 0.3s ease-in-out';

        // *** ИЗМЕНЕНИЕ: Уменьшаем индекс на 3 (постраничная прокрутка) ***
        currentIndex -= itemsPerView;
        moveTrack();

        // Если дошли до начала (показали первую страницу клонов)
        if (currentIndex < 0) {
            setTimeout(() => {
                track.style.transition = 'none'; // Мгновенное смещение
                // Возвращаемся к "настоящему" концу (индекс 3)
                currentIndex = totalItems - itemsPerView;
                moveTrack();
            }, 300);
        }
    });

});
